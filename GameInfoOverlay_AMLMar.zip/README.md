# GTA:SA Game Info Overlay
Displays FPS, RAM usage, and in-game clock on a configurable overlay.
Drop this zip into your `mods/` folder with AMLMar installed.
